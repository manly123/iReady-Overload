let current;

function hasJsonStructure(str) {
    if (typeof str !== 'string') return false;
    try {
        const result = JSON.parse(str);
        const type = Object.prototype.toString.call(result);
        return type === '[object Object]' 
            || type === '[object Array]';
    } catch (err) {
        return false;
    }
}

function getReadingComp(data, mode) {
    let answers = []
    for (let id in data.screens) {
        for (let two in data.screens[id]) {
            if (two.includes("correct") && !two.includes("incorrect") && mode == 1) {
                for (let three in data.screens[id][two]) {
                    if(hasJsonStructure(JSON.stringify(data.screens[id][two][three]))) {
                        answers.push(data.screens[id][two][three]["answer_text"]["value"])
                    }
                }
            } else if (two.includes("part2_stem") && mode == 2) { //multiple choice mode
                for (let i = 0; i < data.screens[id][two]["part2_answer"].length; i++) {
                    console.log("ok")
                    if(data.screens[id][two]["part2_answer"][i]["part2_is_correct"] == true) {
                        if (data.screens[id][two]["part2_answer"][i]["tp_t1_part2_answer_text"]) {
                            answers.push(data.screens[id][two]["part2_answer"][i]["tp_t1_part2_answer_text"]["part2_answer_text"]["value"])
                        }
                    }
                }
            }
        }
    }
    return answers
}

function getReadingComp2(data) {

}

fetch("https://login.i-ready.com/student/v2/web/appstate/DI.ELA.COM.7.1050.10_ad6a58bf-6a80-461f-93b9-b9ddb4d359b0_M_ela?bucket=short_term_unsecured&datatype=json", {
  "headers": {
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-US,en;q=0.9",
    "authorization": "4CDEDECDB121860E73035C3274BFEBF51F21704BBED5D24918BA9D72DD2B457A/782554d0197da2e4facfe36b7e1c7d396633f32e2c4dea6d52e7049cfc012f8b",
    "dashboard-type": "SD",
    "dashboard-version": "release-2.16.x/6",
    "request-id": "7e6e6cca6e2a5fa99cbac764f9bddc6506433868560eee84e50cb4472b9b9d6b",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "sec-gpc": "1",
    "signature": "keyId=\"algo_1\", signature=\"K7XIhhFFGZqOAkfFU1ia//nZqKNB2LlNdLMBAi3Tsao=\"",
    "x-signature": "keyId=\"algo_1\", signature=\"0x000000\""
  },
  "referrer": "https://login.i-ready.com/student/dashboard/home",
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "include"
}).then(response => response.json())
.then(data => {
    current = data.navigationStore.currentStep
    console.log(current)
  html5Iframe.contentWindow.fetch("https://cdn.i-ready.com/instruction/content/reading-comp/lessons/DI.ELA.COM.7.1050/DI.ELA.COM.7.1050.json", {
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": null,
  "method": "GET",
  "mode": "no-cors",
  "credentials": "include"
}).then(response => response.json())
.then(data => {
    let answ = getReadingComp(data, 1)
    let answ2 = getReadingComp(data, 2)
    setInterval(() => {
        
    }, 1000);
    // let a = html5Iframe.contentWindow.document.getElementsByClassName("clickable-inline sub-section-true")
    // for (let i = 0; i < a.length; i++) {
    //     for (let y = 0; y < answ.length; y++) {
    //         //console.log(answ[y] + `<p>${a[i].innerText}</p>`)
    //         if(`<p>${a[i].innerText}</p>` == answ[y]) {
    //             alert(a[i].innerText)
    //         }
    //     }
    // }
})
})